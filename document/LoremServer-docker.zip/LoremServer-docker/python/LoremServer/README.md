Version 2.0 was accidentally deleted

Version 1.0 is stored in another warehouse


# FrontEnd
https://github.com/BladeHiker/LoremSurvey

# LoremServer3
 2.0->3.0

# Increase the CSRF,

### Want to have a faster and more secure 
### cross site verification than Django's own

# change emails
### Change email thread guard wait

# Add the cache system based on redis

# !if the manager change the question have been sent
#  respondent will get the new question one minute later


