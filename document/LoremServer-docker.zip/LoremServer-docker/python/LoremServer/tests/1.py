s = '123456789'
print(s[:5])
print(s[0:5])
print(s[1:])