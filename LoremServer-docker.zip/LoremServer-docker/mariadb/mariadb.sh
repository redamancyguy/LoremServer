sleep 1
mysql -uroot -proot_password < LoremServer.sql
sleep 1